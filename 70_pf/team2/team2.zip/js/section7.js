
$(function () {
    $('.bxslider').bxSlider({
        auto: true,
        autoControls: true,
        stopAutoOnClick: true,
        minSlides: 3,
        maxSlides: 3,
        slideWidth: 360,
        slideMargin: 30
    });
});