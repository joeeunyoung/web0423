
// m: movie
// c: card

const cards = [
    {
        cimg: "https://dessert39.com/data/file/Information/thumb-3543165506_KJlqgvMQ_66f720f95828fd00e6fe91425f482d0446226fb2_300x420.png",
        ctit: "[24년 8월 신메뉴]저칼로리 & 라이스 슬림 요거트 출시!",
        cdate: "24.08.02"
    },
    {
        cimg: "https://dessert39.com/data/file/Information/thumb-3543165506_dtqCPEjF_369ba1cb54467331e5b17e1dc2c0517f315cedd9_300x420.png",
        ctit: "[24년 8월 신메뉴]저칼로리 딸기 음료 출시!",
        cdate: "2024.08.14"
    },
    {
        cimg: "https://dessert39.com/data/file/Information/thumb-3543165506_yT5Q4zbd_ec24c5f7de07e85e0ef8d9040accb7ea94543730_300x420.png",
        ctit: "[24년 8월 신메뉴]피스타치오크림 음료 3종 출시!",
        cdate: "2024.08.28",
    },
    {
        cimg: "https://dessert39.com/data/file/Information/thumb-3543165506_hes5AWGj_256954940c95be8a5a28571938aa0aace04b3d65_300x420.png",
        ctit: "[24년 7월 신메뉴]오레오 쉐이크 3종 출시!",
        cdate: "2024.08.07",
    },
];

// export default cards;